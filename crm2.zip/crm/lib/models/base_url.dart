// ignore_for_file: non_constant_identifier_names

class BaseUrl {
  static String BASE_URL = "http://mermez.xyz/flutter-api";
}
